
if exists(SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.Items') and name='IX_Items_Name_')
drop index IX_Items_Name_ ON dbo.Items 

exec [dbo].[ItemsAdd] @item='������!'
create nonclustered index IX_Items_Name_
ON dbo.Items 
(Name, ExpIncSav)
GO
exec [dbo].[ItemsAdd] @item='������!'
