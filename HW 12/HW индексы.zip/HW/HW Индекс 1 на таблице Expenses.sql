if exists(SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.Expenses') and name='IX_Expenses_DateE')
drop index IX_Expenses_DateE ON dbo.Expenses 

set STATISTICS time, io on 
select * from [dbo].[view_Expenses_all_year](2024,1)
set STATISTICS time, io OFF
create nonclustered index IX_Expenses_DateE
ON dbo.Expenses 
(DateE)
Include(ItemId, SummE, Huge)
GO
set STATISTICS time, io on 
select * from [dbo].[view_Expenses_all_year](2024,1)