USE [Finance]
GO

/****** Object:  Table [dbo].[Income]    Script Date: 01.02.2026 14:53:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Income](
	[IncomeId] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientId] [bigint] NOT NULL,
	[AccountId] [bigint] NOT NULL,
	[ItemId] [bigint] NOT NULL,
	[SummI] [money] NOT NULL,
	[DateI] [datetime] NOT NULL,
	[Description] [varchar](255) NULL,
	[Image] [image] NULL,
	[Is_del] [bit] NULL,
	[Is_test] [bit] NULL,
	[LastUpdate] [datetime] NOT NULL,
	[UserCode] [varchar](30) NOT NULL,
	[TimeStamp] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[IncomeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Income] ADD  CONSTRAINT [DF_Income_DateI]  DEFAULT (getdate()) FOR [DateI]
GO

ALTER TABLE [dbo].[Income] ADD  CONSTRAINT [DF_Income_Is_del]  DEFAULT ((0)) FOR [Is_del]
GO

ALTER TABLE [dbo].[Income] ADD  CONSTRAINT [DF_Income_Is_test]  DEFAULT ((0)) FOR [Is_test]
GO

ALTER TABLE [dbo].[Income] ADD  CONSTRAINT [DF_Income_LastUpdate]  DEFAULT (getdate()) FOR [LastUpdate]
GO

ALTER TABLE [dbo].[Income] ADD  CONSTRAINT [DF_Income_UserCode]  DEFAULT (suser_sname()) FOR [UserCode]
GO

ALTER TABLE [dbo].[Income]  WITH NOCHECK ADD  CONSTRAINT [FK_Accounts_AccountId] FOREIGN KEY([AccountId])
REFERENCES [dbo].[Accounts] ([AccountId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Income] CHECK CONSTRAINT [FK_Accounts_AccountId]
GO

ALTER TABLE [dbo].[Income]  WITH NOCHECK ADD  CONSTRAINT [FK_Income_ClientId] FOREIGN KEY([ClientId])
REFERENCES [dbo].[Clients] ([ClientId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Income] CHECK CONSTRAINT [FK_Income_ClientId]
GO

ALTER TABLE [dbo].[Income]  WITH NOCHECK ADD  CONSTRAINT [FK_Income_ItemId] FOREIGN KEY([ItemId])
REFERENCES [dbo].[Items] ([ItemId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Income] CHECK CONSTRAINT [FK_Income_ItemId]
GO


