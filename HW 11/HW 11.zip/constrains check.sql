alter table [dbo].[Accounts] add Constraint [CH_LastUpdate_XXI_centiry]  check (LastUpdate >= '2000-01-01')
alter table [dbo].[Clients] add Constraint [CH_Phone_Rus]  check (Phonenum>0)
alter table [dbo].[Expenses] add Constraint [CH_SummE]  check (SummE<0)
alter table[dbo].[Income]  add  Constraint [CH_SummI] check  ([SummI]>0)
