USE [Finance]
GO

/****** Object:  Table [dbo].[Items]    Script Date: 01.02.2026 14:51:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Items](
	[ItemId] [bigint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[ClientId] [bigint] NOT NULL,
	[ExpIncSav] [varchar](3) NOT NULL,
	[Description] [varchar](255) NULL,
	[Image] [image] NULL,
	[Is_del] [bit] NULL,
	[Is_test] [bit] NULL,
	[LastUpdate] [datetime] NOT NULL,
	[UserCode] [varchar](30) NOT NULL,
	[TimeStamp] [timestamp] NOT NULL,
	[Huge] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ItemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Items] ADD  CONSTRAINT [DF_Items_Is_del]  DEFAULT ((0)) FOR [Is_del]
GO

ALTER TABLE [dbo].[Items] ADD  CONSTRAINT [DF_Items_Is_test]  DEFAULT ((0)) FOR [Is_test]
GO

ALTER TABLE [dbo].[Items] ADD  CONSTRAINT [DF_Items_LastUpdate]  DEFAULT (getdate()) FOR [LastUpdate]
GO

ALTER TABLE [dbo].[Items] ADD  CONSTRAINT [DF_Items_UserCode]  DEFAULT (suser_sname()) FOR [UserCode]
GO

ALTER TABLE [dbo].[Items]  WITH NOCHECK ADD  CONSTRAINT [FK_Items_ClientId] FOREIGN KEY([ClientId])
REFERENCES [dbo].[Clients] ([ClientId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Items] CHECK CONSTRAINT [FK_Items_ClientId]
GO


