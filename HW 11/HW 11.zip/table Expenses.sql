USE [Finance]
GO

/****** Object:  Table [dbo].[Expenses]    Script Date: 01.02.2026 14:53:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Expenses](
	[ExpenseId] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientId] [bigint] NOT NULL,
	[AccountId] [bigint] NOT NULL,
	[ItemId] [bigint] NOT NULL,
	[SummE] [money] NOT NULL,
	[DateE] [datetime] NOT NULL,
	[Description] [varchar](255) NULL,
	[Image] [image] NULL,
	[Huge] [bit] NULL,
	[FromSavingId] [bigint] NULL,
	[Is_del] [bit] NULL,
	[Is_test] [bit] NULL,
	[LastUpdate] [datetime] NOT NULL,
	[UserCode] [varchar](30) NOT NULL,
	[TimeStamp] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ExpenseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Expenses] ADD  CONSTRAINT [DF_Expenses_DateE]  DEFAULT (getdate()) FOR [DateE]
GO

ALTER TABLE [dbo].[Expenses] ADD  CONSTRAINT [DF_Expenses_Huge]  DEFAULT ((0)) FOR [Huge]
GO

ALTER TABLE [dbo].[Expenses] ADD  CONSTRAINT [DF_Expenses_Is_del]  DEFAULT ((0)) FOR [Is_del]
GO

ALTER TABLE [dbo].[Expenses] ADD  CONSTRAINT [DF_Expenses_Is_test]  DEFAULT ((0)) FOR [Is_test]
GO

ALTER TABLE [dbo].[Expenses] ADD  CONSTRAINT [DF_Expenses_LastUpdate]  DEFAULT (getdate()) FOR [LastUpdate]
GO

ALTER TABLE [dbo].[Expenses] ADD  CONSTRAINT [DF_Expenses_UserCode]  DEFAULT (suser_sname()) FOR [UserCode]
GO

ALTER TABLE [dbo].[Expenses]  WITH NOCHECK ADD  CONSTRAINT [FK_Expenses_AccountId] FOREIGN KEY([AccountId])
REFERENCES [dbo].[Accounts] ([AccountId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Expenses] CHECK CONSTRAINT [FK_Expenses_AccountId]
GO

ALTER TABLE [dbo].[Expenses]  WITH NOCHECK ADD  CONSTRAINT [FK_Expenses_ClientId] FOREIGN KEY([ClientId])
REFERENCES [dbo].[Clients] ([ClientId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Expenses] CHECK CONSTRAINT [FK_Expenses_ClientId]
GO

ALTER TABLE [dbo].[Expenses]  WITH NOCHECK ADD  CONSTRAINT [FK_Expenses_ItemId] FOREIGN KEY([ItemId])
REFERENCES [dbo].[Items] ([ItemId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Expenses] CHECK CONSTRAINT [FK_Expenses_ItemId]
GO


