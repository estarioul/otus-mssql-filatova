USE [Finance]
GO

/****** Object:  Table [dbo].[Clients]    Script Date: 01.02.2026 14:50:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Clients](
	[ClientId] [bigint] IDENTITY(1,1) NOT NULL,
	[Surname] [varchar](50) NULL,
	[Name] [varchar](50) NOT NULL,
	[Otchestvo] [varchar](50) NULL,
	[Phone] [varchar](20) NULL,
	[Phonenum] [bigint] NULL,
	[Email] [varchar](100) NULL,
	[LastUpdate] [datetime] NOT NULL,
	[UserCode] [varchar](30) NOT NULL,
	[TimeStamp] [timestamp] NOT NULL,
	[Is_del] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ClientId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF_Clients_LastUpdate]  DEFAULT (getdate()) FOR [LastUpdate]
GO

ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF_Clients_UserCode]  DEFAULT (suser_sname()) FOR [UserCode]
GO

ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF_Clients_Is_del]  DEFAULT ((0)) FOR [Is_del]
GO


