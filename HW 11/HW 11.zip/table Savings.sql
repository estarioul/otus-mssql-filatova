USE [Finance]
GO

/****** Object:  Table [dbo].[Savings]    Script Date: 01.02.2026 14:54:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Savings](
	[SavingId] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientId] [bigint] NOT NULL,
	[AccountId] [bigint] NOT NULL,
	[ItemId] [bigint] NOT NULL,
	[SummS] [money] NOT NULL,
	[DateS] [datetime] NOT NULL,
	[Description] [varchar](255) NULL,
	[Image] [image] NULL,
	[FromIncomeId] [bigint] NULL,
	[Is_del] [bit] NULL,
	[Is_test] [bit] NULL,
	[LastUpdate] [datetime] NOT NULL,
	[UserCode] [varchar](30) NOT NULL,
	[TimeStamp] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[SavingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Savings] ADD  CONSTRAINT [DF_Savings_DateS]  DEFAULT (getdate()) FOR [DateS]
GO

ALTER TABLE [dbo].[Savings] ADD  CONSTRAINT [DF_Savings_Is_del]  DEFAULT ((0)) FOR [Is_del]
GO

ALTER TABLE [dbo].[Savings] ADD  CONSTRAINT [DF_Savings_Is_test]  DEFAULT ((0)) FOR [Is_test]
GO

ALTER TABLE [dbo].[Savings] ADD  CONSTRAINT [DF_Savings_LastUpdate]  DEFAULT (getdate()) FOR [LastUpdate]
GO

ALTER TABLE [dbo].[Savings] ADD  CONSTRAINT [DF_Savings_UserCode]  DEFAULT (suser_sname()) FOR [UserCode]
GO

ALTER TABLE [dbo].[Savings]  WITH NOCHECK ADD  CONSTRAINT [FK_Savings_AccountId] FOREIGN KEY([AccountId])
REFERENCES [dbo].[Accounts] ([AccountId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Savings] CHECK CONSTRAINT [FK_Savings_AccountId]
GO

ALTER TABLE [dbo].[Savings]  WITH NOCHECK ADD  CONSTRAINT [FK_Savings_ClientId] FOREIGN KEY([ClientId])
REFERENCES [dbo].[Clients] ([ClientId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Savings] CHECK CONSTRAINT [FK_Savings_ClientId]
GO

ALTER TABLE [dbo].[Savings]  WITH NOCHECK ADD  CONSTRAINT [FK_Savings_ItemId] FOREIGN KEY([ItemId])
REFERENCES [dbo].[Items] ([ItemId])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Savings] CHECK CONSTRAINT [FK_Savings_ItemId]
GO


