USE [WideWorldImporters]
GO

/****** Object:  Index [FK_Sales_Invoices_BillToCustomerID]    Script Date: 13.04.2026 8:50:31 ******/
create  INDEX [IX_Invoices_OrderID_InvoiceDate_BillToCustomerID] ON [Sales].[Invoices]
(
	OrderId ,
	InvoiceDate,
	BillToCustomerID
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [USERDATA]
GO


create INDEX [IX_Orders_CustomerID_OrderDate] ON [Sales].[Orders]
(
	CustomerId,
	OrderDate
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [USERDATA]
GO




